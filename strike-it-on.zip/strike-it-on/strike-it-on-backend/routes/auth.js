const Router = require('koa-router');
const router = new Router();
const config = require("../config/config");


router.post("/login", (ctx, next) => {
  let output = {};
  const credentials = {"username": config.username, "password": config.password}
  const { username, password} = ctx.request.body;
  if (username && password) {
    if (username === credentials.username && password === credentials.password) {
      ctx.body = output["data"] = "Success"
    } else {
      ctx.status = 401;
      ctx.body = output["error"] = "Invalid credentials"
    }
  }
});

module.exports = router