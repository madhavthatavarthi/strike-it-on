const Router = require('koa-router');
const router = new Router();
const MockConfig = require("../models/templateconfig");
const R = require('ramda')
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');

router.post("/saveConfig", async (ctx, next) => {
    try {
      const ssn = cryptr.encrypt(ctx.request.body.SSN);
        const mockConfig = new MockConfig({
            FirstName: ctx.request.body.FirstName,
            LastName: ctx.request.body.LastName,
            TelephoneNumber: ctx.request.body.TelephoneNumber,
            Full_Address: ctx.request.body.Full_Address,
            SSN: ssn
        })
        const result = await mockConfig.save()
        if (result) {
          ctx.status = 200;
          ctx.body = result;
        } else {
          ctx.status = 400;
          ctx.body = {"error": "Bad request"}
        }
    } catch(err) {
        ctx.status = 400;
        ctx.body = {"error": "Bad request"}
    }
  })

  router.get("/getConfigDetails", async (ctx, next) => {
    try {
      const configDetails = await MockConfig.find();
      ctx.body = configDetails;
    } catch(err) {
        ctx.status = 400;
        ctx.body = {"error": "Bad request"}
    }
  })

  module.exports = router;