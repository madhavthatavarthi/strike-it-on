mongodb://localhost/mockdata-config

module.exports =   {
    mongoserver:  "mongodb://localhost/strikeiton" || "",
  }