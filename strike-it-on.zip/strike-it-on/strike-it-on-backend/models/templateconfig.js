const mongoose = require('mongoose');

const mockConfigSchema = new mongoose.Schema({
    FirstName: String,
    LastName: String,
    TelephoneNumber: String,
    Full_Address: String,
    SSN: String,
  }
)

const MockConfig = mongoose.model('mockConfig', mockConfigSchema)

module.exports = MockConfig;