const Router = require('koa-router');
const router = new Router();
const MockConfig = require("../models/templateConfig");
const R = require('ramda')


router.post("/saveConfig", async (ctx, next) => {
    try {
;      const config = await MockConfig.find({templateName:  ctx.request.body.templateName})
      if (R.isEmpty(config)) {
        const mockConfig = new MockConfig({
          templateName: ctx.request.body.templateName,
          currentEntityStatus: ctx.request.body.currentEntityStatus,
          entity: ctx.request.body.entityConfig,
          location: ctx.request.body.locationConfig,
        })
        const result = await mockConfig.save()
        if (result) {
          ctx.status = 200;
          ctx.body = result;
        } else {
          ctx.status = 400;
          ctx.body = {"error": "Bad request"}
        }
      } else {
          ctx.status = 400;
          ctx.body = {"error": "Template config name already exists"}
      }
    } catch(err) {
        ctx.status = 400;
        ctx.body = {"error": "Bad request"}
    }
  })

  router.get("/getConfigDetails", async (ctx, next) => {
    try {
      const configDetails = await MockConfig.find();
      ctx.body = configDetails;
    } catch(err) {
        ctx.status = 400;
        ctx.body = {"error": "Bad request"}
    }
  })