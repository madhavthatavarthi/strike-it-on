const Koa = require('koa');
const app = new Koa(); 
const koaBody = require("koa-body")
const mongoose = require('mongoose');
const config = require("./config/config");
// const configRouter = require("./routes/crud")
// const authRouter = require("./routes/authentication")

app.use(koaBody({
      json: true,
      multipart: true,
      urlencoded: true,
      text: true,
      jsonLimit: "50mb",
    }))
    mongoose.connect(config.mongoserver, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(()=> console.log('connected to mongo-exercise collection'))
    .catch(err => console.log(err));

  app.use(configRouter.routes());
  app.use(configRouter.allowedMethods());
  app.use(dataRouter.routes());
  app.use(dataRouter.allowedMethods())
  app.use(authRouter.routes());
  app.use(authRouter.allowedMethods())

const port = process.env.PORT || 8080
app.listen(port, () => console.log('App is listening on port' + " " + port));