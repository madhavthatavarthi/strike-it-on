const Koa = require('koa');
const app = new Koa(); 
var cors = require('@koa/cors')
const koaBody = require("koa-body")
const mongoose = require('mongoose');
const config = require("./config/config");
const serve = require("koa-static");
const configRouter = require("./routes/crud")
const dataRouter = require("./routes/generateData")
const authRouter = require("./routes/authentication")
const redisInitialise = require("./utils/redis")

app.use(cors());
app.use(koaBody({
      json: true,
      multipart: true,
      urlencoded: true,
      text: true,
      jsonLimit: "50mb",
    }))
app.use(serve(__dirname + "/dist"))
    mongoose.connect(config.mongoserver, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(()=> console.log('connected to mongo-exercise collection'))
    .catch(err => console.log(err));

    redisInitialise.redisInitialise();

  app.use(configRouter.routes());
  app.use(configRouter.allowedMethods());
  app.use(dataRouter.routes());
  app.use(dataRouter.allowedMethods())
  app.use(authRouter.routes());
  app.use(authRouter.allowedMethods())

const port = process.env.PORT || 8080
app.listen(port, () => console.log('App is listening on port' + " " + port));