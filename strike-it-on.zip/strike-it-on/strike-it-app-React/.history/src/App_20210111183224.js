import React from 'react';
import { Card, Button, Form, Nav } from "react-bootstrap";
import { NavLink, Nav } from "react-router-dom";
 import axios from 'axios';
import './styles/loginpage.css'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class App extends React.Component {
    constructor(props){
        super(props);
        this.state={
          FirstName:'',
        LastName:'',
        Telephone:'',
        FullAddress:'',
        SSN:''


        }
       }

       storeUser = async event => {
        const params = {
          url: "http://localhost:7000/saveConfig",
          method: "POST",
          headers: {
            accept: "application/json",
            "Content-Type": "application/json"
          },
          data: {},
          json: true
        }
        params.data = {
          "FirstName":this.state.FirstName,
          "LastName": this.state.LastName,
          "TelephoneNumber": this.state.Telephone,
          "Full_Address": this.state.FullAddress,
          "SSN": this.state.SSN 
          }
          let data = await axios(params)
          console.log("data<><><>",data.status);
          if (data.status === 200) {
          console.log("data<><><>",data.status);
            toast.info("Successfully updated database", {
              position: toast.POSITION.BOTTOM_CENTER
            });
         }
       }
      render() {
        return (
          <div className="container box">
          <Nav className="mc-nav-items"
            activeKey="/" >
          <Nav.Item>
            <Nav.Link as={NavLink} exact to="/login" activeStyle={blue}>Home</Nav.Link>
          </Nav.Item>
        </Nav>
          
              <Card>
                  <Card.Header as="h5">User details</Card.Header>
                  <Card.Body>
                  <div >
                      <Form.Label>FirstName</Form.Label>
                      <Form.Control name="FirstName" placeholder={"First Name"}  className="float-middle" onChange = {(event) => this.setState({FirstName:event.target.value})} type="text" />
                  </div>

                  <div >
                      <Form.Label>LastName</Form.Label>
                      <Form.Control name="LastName" type="text" placeholder={"Last Name"} className="float-middle" onChange = {(event) => this.setState({LastName:event.target.value})}/>
                  </div>
                  <div >
                      <Form.Label>Telephone</Form.Label>
                      <Form.Control name="Telephone" placeholder={"Telephone"}  className="float-middle" onChange = {(event) => this.setState({Telephone:event.target.value})} type="text" />
                  </div>

                  <div >
                      <Form.Label>FullAddress</Form.Label>
                      <Form.Control name="FullAddress" type="text" placeholder={"FullAddress"} className="float-middle" onChange = {(event) => this.setState({FullAddress:event.target.value})}/>
                  </div>
                  <div >
                      <Form.Label>SSN</Form.Label>
                      <Form.Control name="SSN" type="text" placeholder={"SSN"} className="float-middle" onChange = {(event) => this.setState({SSN:event.target.value})}/>
                  </div>
                  </Card.Body>
                  <Card.Body>
                  <Button onClick={(e) => this.storeUser(e)} name={"login"} className="float-middle" variant="info" size="sm" > Submit </Button>
                  </Card.Body>
              </Card>
              </div>
    );
  }
}

export default App