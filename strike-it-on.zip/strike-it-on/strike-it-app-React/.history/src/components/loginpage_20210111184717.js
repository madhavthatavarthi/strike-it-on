import React from 'react';
import { Card, Button, Form } from "react-bootstrap";
import { withRouter } from "react-router-dom";
import axios from 'axios';
import '../styles/loginpage.css'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class LoginPage extends React.Component {
    constructor(props){
        super(props);
        this.state={
        username:'',
        password:''
        }
       }
     validateUser = async event => {
        console.log("render home page", this.state.username);
        
        try {
          const params = apiConstants.mockEngine.userLogin.login
          params.data = {
            "username":this.state.username,
            "password": this.state.password,
            }
            let data = await axios(params)
            if (data.status === 200) {
              localStorage.setItem('user', this.state.username);
              console.log("this.propsLoginL::::", this.props)
              this.props.history.push("/home")
           }

          } catch(err) {
              toast.error("Invalid Credentials !", {
              position: toast.POSITION.BOTTOM_CENTER
            });
            console.log("err", err)
          }
       }
      render() {
        localStorage.removeItem('user');
        return (
          <div className="container box">
              <Card>
                  <Card.Header as="h5">Login</Card.Header>
                  <Card.Body>
                  <div style={{ width: 200 }}>
                      <Form.Label>UserName</Form.Label>
                      <form.contorl name="Username" placeholder={"Enter Username"}  className="float-middle" onChange = {(event) => this.setState({username:event.target.value})} type="text" />
                  </div>

                  <div style={{ width: 200 }}>
                      <Form.Label>Password</Form.Label>
                      <form.contorl name="password" type="password" placeholder={"Enter Password"} className="float-middle" onChange = {(event) => this.setState({password:event.target.value})}/>
                  </div>
                  </Card.Body>
                  <Card.Body>
                  <Button onClick={(e) => this.validateUser(e)} name={"login"} className="float-middle" variant="info" size="sm" > Submit </Button>
                  </Card.Body>
              </Card>
              </div>
    );
  }
}

export default withRouter(LoginPage)